from django.db import models

class Voter(models.Model):
    name = models.CharField(max_length=100)

class Vote(models.Model):
    voter = models.ForeignKey(Voter, on_delete=models.CASCADE)
    option = models.CharField(max_length=100)
    timestamp = models.DateTimeField(auto_now_add=True)