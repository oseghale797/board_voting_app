from django.shortcuts import render
from .models import Vote

def index(request):
    votes = Vote.objects.all()
    return render(request, 'voting_app/index.html', {'votes': votes})