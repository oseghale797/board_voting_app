from django.contrib import admin
from .models import Voter, Vote

admin.site.register(Voter)
admin.site.register(Vote)